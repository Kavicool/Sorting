package com.hm.sorting.service;

import com.hm.sorting.domain.SortedResult;

/**
 * Interface sortingService
 */
public interface SortingService {
	SortedResult sortOrder(String sortNumbers);
}
