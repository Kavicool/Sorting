package com.hm.sorting.service;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hm.sorting.domain.Sorting;
import com.hm.sorting.repository.ISortingRepository;

@Service
public class SortingServiceImpl implements SortingService {

	@Autowired
	private ISortingRepository repository;

	@Override
	public Sorting sortOrder(String sortNumbers) {
		Instant start = Instant.now();

		Sorting sortValue = new Sorting();
		sortValue.setBeforeSort(sortNumbers);

		Pattern pattern = Pattern.compile(",");
		List<Integer> list = pattern.splitAsStream(sortNumbers).map(Integer::valueOf).collect(Collectors.toList());
		list.sort(Comparator.naturalOrder());
		
		String numberString = list.stream().map(String::valueOf)
			    .collect(Collectors.joining(","));
		
		sortValue.setAfterSort(numberString);

		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis(); // in millis
		sortValue.setTimeToSort(Long.toString(timeElapsed));

		repository.save(sortValue);
		return sortValue;
	}
}
