package com.hm.sorting.service;

import com.hm.sorting.domain.Sorting;

/**
 * Interface sortingService
 */
public interface SortingService {
	Sorting sortOrder(String sortNumbers);
}
