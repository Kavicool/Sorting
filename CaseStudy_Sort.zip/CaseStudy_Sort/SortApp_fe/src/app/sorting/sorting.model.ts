export interface Sorting {
    beforeSort: string;
    afterSort: string;
    timeToSort: string;
    intervals: string;
}
